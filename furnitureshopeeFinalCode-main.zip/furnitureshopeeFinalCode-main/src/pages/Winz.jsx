import React, { useState, useEffect } from "react";

import CommonSection from "../components/UI/CommonSection";
import Helmet from "../components/Helmet/Helmet";
import { Container, Row, Col } from "reactstrap";

import "../styles/shop.css";

import ProductsList from "../components/UI/ProductsList";
import useGetData from "../custom-hooks/useGetData";
 



const Winz = () => {
  const { data: products, loading } = useGetData("products");

  const [winzProducts, setWinzProducts] = useState([]);


  useEffect(() => {
    const filteredWinzProducts = products.filter(
      item => item.category === "Winz"
    );



    setWinzProducts(filteredWinzProducts);

  }, [products]);
 

  return (
    <Helmet title="Winz Catalogue">
      <CommonSection title="Winz Catalogue" />

      <section>
        <Container>
          <Row>
          <div className="winz">
                <p> 
                Our company is happy to provide Work and Income Quote. We are an approved supplier for Work and Income New Zealand. 
                We will arrange either a pick-up or delivery of your requested items once we received payment.
                        </p>
                        </div>
                        

          </Row>
        </Container>
      </section>


      <section className="trending__products">
        <Container>
          <Row>
            <Col lg="12" className="text-center">
              <h2 className="section__title">WINZ Catalogue</h2>
            </Col>

            {loading ? (
              <h5 className="fw-bold">Loading....</h5>
            ) : (
              <ProductsList data={winzProducts} />
            )}
          </Row>
        </Container>
      </section>
    </Helmet>
  );
};

export default Winz;